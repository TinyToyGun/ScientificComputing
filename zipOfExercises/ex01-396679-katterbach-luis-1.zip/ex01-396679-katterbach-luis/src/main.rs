fn main() {
    println!("Luis Katterbach: Hello Scientific Computing");
}
